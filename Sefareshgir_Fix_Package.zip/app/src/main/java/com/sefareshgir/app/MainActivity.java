package com.sefareshgir.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.*;

public class MainActivity extends Activity {
    private LinearLayout layout;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(24, 30, 24, 24);
        layout.setBackgroundColor(Color.rgb(246,248,247));

        TextView title = new TextView(this);
        title.setText("سفارش‌یار");
        title.setTextSize(30);
        title.setTextColor(Color.rgb(7,91,67));
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 18, 0, 24);
        layout.addView(title);

        addButton("📦 مدیریت کالاها", ProductActivity.class);
        addButton("👥 مدیریت مشتریان", CustomerActivity.class);
        addButton("🧾 ثبت سفارش", OrderActivity.class);
        addButton("💰 دریافت پرداخت", PaymentActivity.class);

        TextView note = new TextView(this);
        note.setText("مدیریت کالا، مشتری، سفارش و دریافت وجه");
        note.setGravity(Gravity.CENTER);
        note.setTextColor(Color.DKGRAY);
        note.setPadding(0, 28, 0, 0);
        layout.addView(note);
        setContentView(layout);
    }

    private void addButton(String label, Class<?> target) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextSize(17);
        button.setAllCaps(false);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 64);
        p.setMargins(0, 8, 0, 8);
        layout.addView(button, p);
        button.setOnClickListener(v -> startActivity(new Intent(this, target)));
    }
}
