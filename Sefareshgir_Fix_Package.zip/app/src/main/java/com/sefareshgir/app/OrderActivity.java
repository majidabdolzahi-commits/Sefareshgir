package com.sefareshgir.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.*;
import android.database.Cursor;
import java.util.ArrayList;

public class OrderActivity extends Activity {
    private Database db;
    private Spinner customerSpinner, productSpinner;
    private EditText quantityField, paidField;
    private TextView priceView, totalView;
    private final ArrayList<Long> customerIds = new ArrayList<>();
    private final ArrayList<Long> productIds = new ArrayList<>();
    private final ArrayList<String> productNames = new ArrayList<>();
    private final ArrayList<Long> productPrices = new ArrayList<>();
    private final ArrayList<Long> productBuys = new ArrayList<>();
    private final ArrayList<CartLine> cart = new ArrayList<>();
    private long total = 0;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        db = new Database(this);
        showScreen(); loadCustomers(); loadProducts(); updateTotal();
    }

    private void showScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(1); root.setPadding(18,18,18,18);
        root.setBackgroundColor(Color.rgb(246,248,247));
        TextView title = new TextView(this);
        title.setText("ثبت سفارش جدید"); title.setTextSize(24);
        title.setTextColor(Color.rgb(7,91,67)); title.setGravity(Gravity.CENTER);
        title.setPadding(5,15,5,20); root.addView(title);

        TextView cl = new TextView(this); cl.setText("انتخاب مشتری"); root.addView(cl);
        customerSpinner = new Spinner(this); root.addView(customerSpinner);
        TextView pl = new TextView(this); pl.setText("انتخاب کالا"); pl.setPadding(0,15,0,0); root.addView(pl);
        productSpinner = new Spinner(this); root.addView(productSpinner);
        priceView = new TextView(this); priceView.setPadding(0,10,0,10); root.addView(priceView);
        quantityField = new EditText(this); quantityField.setHint("تعداد به عدد");
        quantityField.setInputType( android.text.InputType.TYPE_CLASS_NUMBER); root.addView(quantityField);
        Button add = new Button(this); add.setText("افزودن کالا به سفارش"); add.setAllCaps(false); root.addView(add);
        TextView cartTitle = new TextView(this); cartTitle.setText("اقلام سفارش"); cartTitle.setTextSize(19);
        cartTitle.setPadding(0,20,0,10); root.addView(cartTitle);
        totalView = new TextView(this); totalView.setTextSize(17); totalView.setTextColor(Color.rgb(7,91,67));
        totalView.setPadding(0,10,0,10); root.addView(totalView);
        paidField = new EditText(this); paidField.setHint("مبلغ پرداختی (ریال)");
        paidField.setInputType(android.text.InputType.TYPE_CLASS_NUMBER); root.addView(paidField);
        Button save = new Button(this); save.setText("ثبت نهایی سفارش"); save.setAllCaps(false); root.addView(save);
        add.setOnClickListener(v -> addToCart()); save.setOnClickListener(v -> saveOrder());
        setContentView(root);
    }

    private void loadCustomers() {
        customerIds.clear(); ArrayList<String> names = new ArrayList<>();
        names.add("مشتری متفرقه"); customerIds.add(-1L);
        Cursor c=db.customers();
        while(c.moveToNext()) { customerIds.add(c.getLong(c.getColumnIndexOrThrow("id")));
            names.add(c.getString(c.getColumnIndexOrThrow("name"))); }
        c.close();
        ArrayAdapter<String> a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,names);
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); customerSpinner.setAdapter(a);
    }

    private void loadProducts() {
        productIds.clear(); productNames.clear(); productPrices.clear(); productBuys.clear();
        ArrayList<String> names=new ArrayList<>(); Cursor c=db.products();
        while(c.moveToNext()) {
            int stock=c.getInt(c.getColumnIndexOrThrow("stock_pieces")); if(stock<=0) continue;
            productIds.add(c.getLong(c.getColumnIndexOrThrow("id")));
            productNames.add(c.getString(c.getColumnIndexOrThrow("name")));
            productPrices.add(c.getLong(c.getColumnIndexOrThrow("piece_price")));
            productBuys.add(c.getLong(c.getColumnIndexOrThrow("buy_price")));
            names.add(productNames.get(productNames.size()-1)+" | موجودی: "+stock);
        }
        c.close();
        ArrayAdapter<String> a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,names);
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); productSpinner.setAdapter(a);
        productSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> p, android.view.View v,int pos,long id) {
                if(pos>=0 && pos<productPrices.size()) priceView.setText("قیمت فروش هر عدد: "+productPrices.get(pos)+" ریال");
                else priceView.setText("کالای موجودی‌دار ثبت نشده است.");
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> p) {}
        });
    }

    private void addToCart() {
        int pos=productSpinner.getSelectedItemPosition();
        if(pos<0 || pos>=productIds.size()) { Toast.makeText(this,"ابتدا کالای دارای موجودی ثبت کن.",Toast.LENGTH_SHORT).show(); return; }
        try {
            int qty=Integer.parseInt(quantityField.getText().toString().trim());
            if(qty<=0) throw new NumberFormatException();
            long id=productIds.get(pos); int stock=0; Cursor c=db.products();
            while(c.moveToNext()) if(c.getLong(c.getColumnIndexOrThrow("id"))==id) {
                stock=c.getInt(c.getColumnIndexOrThrow("stock_pieces")); break;
            }
            c.close();
            int inCart=0; for(CartLine line:cart) if(line.productId==id) inCart+=line.qty;
            if((long)inCart+qty>stock) { Toast.makeText(this,"موجودی کالا کافی نیست.",Toast.LENGTH_LONG).show(); return; }
            cart.add(new CartLine(id,productNames.get(pos),qty,productPrices.get(pos),productBuys.get(pos)));
            quantityField.setText(""); updateTotal();
            Toast.makeText(this,"کالا به سفارش اضافه شد.",Toast.LENGTH_SHORT).show();
        } catch(NumberFormatException e) { quantityField.setError("تعداد معتبر وارد کن"); }
    }

    private void updateTotal() {
        total=0; StringBuilder s=new StringBuilder();
        for(CartLine line:cart) { long lineTotal=(long)line.qty*line.price; total+=lineTotal;
            s.append(line.name).append(" | ").append(line.qty).append(" عدد | ").append(lineTotal).append(" ریال\n"); }
        totalView.setText("اقلام سفارش:\n"+s+"\nمبلغ کل: "+total+" ریال");
    }

    private void saveOrder() {
        if(cart.isEmpty()) { Toast.makeText(this,"هیچ کالایی به سفارش اضافه نشده است.",Toast.LENGTH_SHORT).show(); return; }
        try {
            long paid=paidField.getText().toString().trim().isEmpty()?0:Long.parseLong(paidField.getText().toString().trim());
            if(paid<0 || paid>total) { paidField.setError("مبلغ پرداختی نامعتبر است."); return; }
            int pos=customerSpinner.getSelectedItemPosition();
            if(pos<0 || pos>=customerIds.size()) pos=0;
            long orderId=db.createOrder(customerIds.get(pos),cart,paid);
            if(orderId==-1) { Toast.makeText(this,"ثبت سفارش انجام نشد؛ موجودی کالا را بررسی کن.",Toast.LENGTH_LONG).show(); return; }
            new AlertDialog.Builder(this).setTitle("سفارش ثبت شد")
                .setMessage("شماره سفارش: "+orderId+"\nمبلغ کل: "+total+" ریال\nپرداخت‌شده: "+paid+" ریال\nباقی‌مانده: "+(total-paid)+" ریال")
                .setPositiveButton("باشه",(d,w)->{cart.clear();total=0;paidField.setText("");quantityField.setText("");updateTotal();loadProducts();})
                .show();
        } catch(NumberFormatException e) { paidField.setError("مبلغ معتبر وارد کن"); }
    }
}
