package com.sefareshgir.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.*;
import android.database.Cursor;

public class PaymentActivity extends Activity {
    private Database db;
    private LinearLayout listLayout;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        db = new Database(this);
        showScreen();
        loadOrders();
    }

    @Override protected void onResume() {
        super.onResume();
        if (listLayout != null) loadOrders();
    }

    private void showScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(16,16,16,16);
        root.setBackgroundColor(Color.rgb(246,248,247));
        TextView title = new TextView(this);
        title.setText("دریافت پرداخت‌ها"); title.setTextSize(24);
        title.setTextColor(Color.rgb(7,91,67)); title.setGravity(Gravity.CENTER);
        title.setPadding(5,15,5,20); root.addView(title);
        ScrollView scroll = new ScrollView(this);
        listLayout = new LinearLayout(this); listLayout.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(listLayout); root.addView(scroll);
        setContentView(root);
    }

    private void loadOrders() {
        listLayout.removeAllViews();
        Cursor c = db.orders();
        long debt = 0; int count = 0;
        while (c.moveToNext()) {
            long id=c.getLong(c.getColumnIndexOrThrow("id"));
            long total=c.getLong(c.getColumnIndexOrThrow("total"));
            long paid=c.getLong(c.getColumnIndexOrThrow("paid"));
            String customer=c.getString(c.getColumnIndexOrThrow("customer_name"));
            long remaining=total-paid;
            if (remaining <= 0) continue;
            if (customer == null || customer.isEmpty()) customer="مشتری متفرقه";
            debt += remaining; count++;
            addCard(id, customer, total, paid, remaining);
        }
        c.close();
        TextView summary = new TextView(this);
        summary.setText("تعداد سفارش‌های بدهکار: "+count+"\nمجموع بدهی: "+debt+" ریال");
        summary.setTextSize(17); summary.setTextColor(Color.rgb(7,91,67));
        summary.setPadding(10,15,10,20); listLayout.addView(summary);
        if (count == 0) {
            TextView empty = new TextView(this); empty.setText("هیچ سفارش بدهکاری وجود ندارد.");
            empty.setGravity(Gravity.CENTER); empty.setPadding(10,30,10,30); listLayout.addView(empty);
        }
    }

    private void addCard(long id, String customer, long total, long paid, long remaining) {
        LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(15,15,15,15); card.setBackgroundColor(Color.WHITE);
        TextView info = new TextView(this);
        info.setText("شماره سفارش: "+id+"\nمشتری: "+customer+"\nمبلغ کل: "+total+
            " ریال\nپرداخت‌شده: "+paid+" ریال\nمانده بدهی: "+remaining+" ریال");
        info.setTextSize(15); card.addView(info);
        Button button = new Button(this); button.setText("ثبت پرداخت جدید"); button.setAllCaps(false);
        button.setOnClickListener(v -> paymentDialog(id, remaining)); card.addView(button);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2);
        p.setMargins(0,5,0,12); listLayout.addView(card,p);
    }

    private void paymentDialog(long id, long remaining) {
        EditText field = new EditText(this); field.setHint("مبلغ دریافتی به ریال");
        field.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("ثبت پرداخت سفارش "+id)
            .setMessage("مانده بدهی: "+remaining+" ریال").setView(field)
            .setPositiveButton("ثبت",null).setNegativeButton("انصراف",null).create();
        dialog.setOnShowListener(x -> dialog.getButton(-1).setOnClickListener(v -> {
            String value=field.getText().toString().trim();
            try {
                long amount=Long.parseLong(value);
                if (amount<=0 || amount>remaining) { field.setError("مبلغ باید بیشتر از صفر و حداکثر برابر بدهی باشد."); return; }
                db.addPayment(id,amount);
                dialog.dismiss(); loadOrders();
                Toast.makeText(this,"پرداخت ثبت شد.",Toast.LENGTH_SHORT).show();
            } catch (Exception e) { field.setError("مبلغ معتبر وارد کن"); }
        }));
        dialog.show();
    }
}
