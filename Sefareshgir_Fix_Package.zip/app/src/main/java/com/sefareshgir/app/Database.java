package com.sefareshgir.app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class Database extends SQLiteOpenHelper {
    private static final String DB_NAME = "sefareshgir.db";
    private static final int DB_VERSION = 2;

    public Database(Context context) { super(context, DB_NAME, null, DB_VERSION); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE products (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, category TEXT, unit TEXT DEFAULT 'عدد', per_carton INTEGER DEFAULT 1, buy_price INTEGER DEFAULT 0, piece_price INTEGER DEFAULT 0, carton_price INTEGER DEFAULT 0, stock_pieces INTEGER DEFAULT 0, photo TEXT)");
        db.execSQL("CREATE TABLE customers (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, phone TEXT, address TEXT)");
        db.execSQL("CREATE TABLE orders (id INTEGER PRIMARY KEY AUTOINCREMENT, customer_id INTEGER, customer_name TEXT, created_at TEXT, total INTEGER DEFAULT 0, paid INTEGER DEFAULT 0, profit INTEGER DEFAULT 0, note TEXT)");
        db.execSQL("CREATE TABLE order_items (id INTEGER PRIMARY KEY AUTOINCREMENT, order_id INTEGER, product_id INTEGER, product_name TEXT, quantity_pieces INTEGER, unit_price INTEGER, buy_price INTEGER, line_total INTEGER)");
        db.execSQL("CREATE TABLE payments (id INTEGER PRIMARY KEY AUTOINCREMENT, order_id INTEGER, amount INTEGER, created_at TEXT)");
        db.execSQL("CREATE TABLE settings (key TEXT PRIMARY KEY, value TEXT)");
        db.execSQL("INSERT INTO settings(key,value) VALUES ('store_name','فروشگاه من'),('store_phone','')");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            // Keep existing records; add the fields used by the corrected order flow.
            try { db.execSQL("ALTER TABLE orders ADD COLUMN customer_name TEXT"); } catch (Exception ignored) {}
            try { db.execSQL("ALTER TABLE orders ADD COLUMN created_at TEXT"); } catch (Exception ignored) {}
        }
    }

    private String now() {
        return new SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.getDefault()).format(new Date());
    }

    public long addProduct(String name, String category, int perCarton, long buyPrice,
                           long piecePrice, long cartonPrice, int stock) {
        ContentValues v = new ContentValues();
        v.put("name", name); v.put("category", category); v.put("per_carton", Math.max(1, perCarton));
        v.put("buy_price", buyPrice); v.put("piece_price", piecePrice);
        v.put("carton_price", cartonPrice); v.put("stock_pieces", stock);
        return getWritableDatabase().insert("products", null, v);
    }

    public Cursor products() {
        return getReadableDatabase().rawQuery("SELECT * FROM products ORDER BY name", null);
    }

    public long addCustomer(String name, String phone, String address) {
        ContentValues v = new ContentValues();
        v.put("name", name); v.put("phone", phone); v.put("address", address);
        return getWritableDatabase().insert("customers", null, v);
    }

    public Cursor customers() {
        return getReadableDatabase().rawQuery("SELECT * FROM customers ORDER BY name", null);
    }

    public Cursor orders() {
        return getReadableDatabase().rawQuery("SELECT * FROM orders ORDER BY id DESC", null);
    }

    public long createOrder(long customerId, ArrayList<CartLine> items, long paid) {
        if (items == null || items.isEmpty() || paid < 0) return -1;
        long total = 0, profit = 0;
        for (CartLine item : items) {
            if (item.qty <= 0 || item.price < 0 || item.buy < 0) return -1;
            total += (long)item.qty * item.price;
            profit += (long)item.qty * (item.price - item.buy);
        }
        if (paid > total) return -1;

        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            String customerName = "مشتری متفرقه";
            if (customerId > 0) {
                Cursor c = db.rawQuery("SELECT name FROM customers WHERE id=?",
                    new String[]{String.valueOf(customerId)});
                if (c.moveToFirst()) customerName = c.getString(0);
                c.close();
            }

            ContentValues order = new ContentValues();
            order.put("customer_id", customerId > 0 ? customerId : null);
            order.put("customer_name", customerName);
            order.put("created_at", now());
            order.put("total", total);
            order.put("paid", paid);
            order.put("profit", profit);
            long orderId = db.insertOrThrow("orders", null, order);

            for (CartLine item : items) {
                ContentValues row = new ContentValues();
                row.put("order_id", orderId); row.put("product_id", item.productId);
                row.put("product_name", item.name); row.put("quantity_pieces", item.qty);
                row.put("unit_price", item.price); row.put("buy_price", item.buy);
                row.put("line_total", (long)item.qty * item.price);
                db.insertOrThrow("order_items", null, row);

                android.database.sqlite.SQLiteStatement st = db.compileStatement(
                    "UPDATE products SET stock_pieces=stock_pieces-? WHERE id=? AND stock_pieces>=?");
                st.bindLong(1, item.qty); st.bindLong(2, item.productId); st.bindLong(3, item.qty);
                int changed = st.executeUpdateDelete();
                st.close();
                if (changed != 1) return -1;
            }

            if (paid > 0) {
                ContentValues payment = new ContentValues();
                payment.put("order_id", orderId); payment.put("amount", paid); payment.put("created_at", now());
                db.insertOrThrow("payments", null, payment);
            }
            db.setTransactionSuccessful();
            return orderId;
        } catch (Exception e) {
            return -1;
        } finally {
            db.endTransaction();
        }
    }

    public void addPayment(long orderId, long amount) {
        if (amount <= 0) return;
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            Cursor c = db.rawQuery("SELECT total,paid FROM orders WHERE id=?",
                new String[]{String.valueOf(orderId)});
            if (!c.moveToFirst()) { c.close(); return; }
            long remaining = c.getLong(0) - c.getLong(1);
            c.close();
            if (amount > remaining) return;

            ContentValues payment = new ContentValues();
            payment.put("order_id", orderId); payment.put("amount", amount); payment.put("created_at", now());
            db.insertOrThrow("payments", null, payment);
            db.execSQL("UPDATE orders SET paid=paid+? WHERE id=?", new Object[]{amount, orderId});
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
    }

    public long scalar(String sql) {
        Cursor c = getReadableDatabase().rawQuery(sql, null);
        try { return c.moveToFirst() ? c.getLong(0) : 0; }
        finally { c.close(); }
    }

    public String setting(String key) {
        Cursor c = getReadableDatabase().rawQuery("SELECT value FROM settings WHERE key=?",
            new String[]{key});
        try { return c.moveToFirst() ? c.getString(0) : ""; }
        finally { c.close(); }
    }

    public void setSetting(String key, String value) {
        ContentValues v = new ContentValues(); v.put("key", key); v.put("value", value);
        getWritableDatabase().insertWithOnConflict("settings", null, v, SQLiteDatabase.CONFLICT_REPLACE);
    }
}
