package com.sefareshgir.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.*;
import android.database.Cursor;

public class ProductActivity extends Activity {
    private Database db;
    private LinearLayout listLayout;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state); db=new Database(this); showScreen(); loadProducts();
    }

    private void showScreen() {
        LinearLayout root=new LinearLayout(this); root.setOrientation(1);
        root.setPadding(16,16,16,16); root.setBackgroundColor(Color.rgb(246,248,247));
        TextView title=new TextView(this); title.setText("مدیریت کالاها"); title.setTextSize(24);
        title.setTextColor(Color.rgb(7,91,67)); title.setGravity(Gravity.CENTER);
        title.setPadding(5,15,5,20); root.addView(title);
        Button add=new Button(this); add.setText("＋ افزودن کالای جدید"); add.setAllCaps(false);
        add.setOnClickListener(v -> addProductDialog()); root.addView(add);
        ScrollView scroll=new ScrollView(this); listLayout=new LinearLayout(this);
        listLayout.setOrientation(1); scroll.addView(listLayout); root.addView(scroll); setContentView(root);
    }

    private void loadProducts() {
        listLayout.removeAllViews(); Cursor c=db.products();
        if(c.getCount()==0){TextView e=new TextView(this);e.setText("هنوز کالایی ثبت نشده است.");e.setGravity(Gravity.CENTER);e.setPadding(10,30,10,30);listLayout.addView(e);}
        while(c.moveToNext()) {
            String name=c.getString(c.getColumnIndexOrThrow("name"));
            String category=c.getString(c.getColumnIndexOrThrow("category"));
            int carton=c.getInt(c.getColumnIndexOrThrow("per_carton"));
            long buy=c.getLong(c.getColumnIndexOrThrow("buy_price"));
            long piece=c.getLong(c.getColumnIndexOrThrow("piece_price"));
            long cartonPrice=c.getLong(c.getColumnIndexOrThrow("carton_price"));
            int stock=c.getInt(c.getColumnIndexOrThrow("stock_pieces"));
            TextView card=new TextView(this);
            card.setText(name+"\nدسته‌بندی: "+category+"\nهر کارتن: "+carton+" عدد"+
                "\nقیمت خرید: "+buy+" ریال\nفروش عددی: "+piece+" ریال"+
                "\nفروش کارتنی: "+cartonPrice+" ریال\nموجودی: "+stock+" عدد");
            card.setTextSize(15); card.setTextColor(Color.DKGRAY); card.setPadding(15,15,15,15);
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,6,0,10);listLayout.addView(card,p);
        }
        c.close();
    }

    private EditText field(LinearLayout box,String hint,boolean numeric) {
        EditText e=new EditText(this);e.setHint(hint);e.setSingleLine(true);
        if(numeric)e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        box.addView(e);return e;
    }

    private void addProductDialog() {
        ScrollView scroll=new ScrollView(this);LinearLayout form=new LinearLayout(this);
        form.setOrientation(1);form.setPadding(20,10,20,10);
        EditText name=field(form,"نام کالا",false), category=field(form,"دسته‌بندی",false);
        EditText per=field(form,"تعداد عدد در هر کارتن",true), buy=field(form,"قیمت خرید هر عدد (ریال)",true);
        EditText piece=field(form,"قیمت فروش هر عدد (ریال)",true), carton=field(form,"قیمت فروش هر کارتن (ریال)",true);
        EditText cartons=field(form,"موجودی کارتن",true), pieces=field(form,"موجودی عدد",true);
        scroll.addView(form);
        AlertDialog d=new AlertDialog.Builder(this).setTitle("ثبت کالای جدید").setView(scroll)
            .setPositiveButton("ثبت",null).setNegativeButton("انصراف",null).create();
        d.setOnShowListener(x -> d.getButton(-1).setOnClickListener(v -> {
            try {
                String n=name.getText().toString().trim(), cat=category.getText().toString().trim();
                int pc=Integer.parseInt(per.getText().toString().trim());
                long b=Long.parseLong(buy.getText().toString().trim());
                long pp=Long.parseLong(piece.getText().toString().trim());
                long cp=Long.parseLong(carton.getText().toString().trim());
                int cs=Integer.parseInt(cartons.getText().toString().trim());
                int ps=Integer.parseInt(pieces.getText().toString().trim());
                if(n.isEmpty()){name.setError("نام کالا را وارد کن");return;}
                if(pc<=0||cs<0||ps<0||ps>=pc||b<0||pp<0||cp<0){Toast.makeText(this,"اطلاعات واردشده معتبر نیست.",Toast.LENGTH_LONG).show();return;}
                long stock=(long)cs*pc+ps;if(stock>Integer.MAX_VALUE){Toast.makeText(this,"موجودی بیش از حد مجاز است.",Toast.LENGTH_LONG).show();return;}
                db.addProduct(n,cat.isEmpty()?"عمومی":cat,pc,b,pp,cp,(int)stock);
                d.dismiss();loadProducts();Toast.makeText(this,"کالا ثبت شد.",Toast.LENGTH_SHORT).show();
            } catch(Exception e){Toast.makeText(this,"تمام فیلدهای عددی را درست تکمیل کن.",Toast.LENGTH_LONG).show();}
        }));
        d.show();
    }
}
