package com.sefareshgir.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.*;
import android.database.Cursor;

public class CustomerActivity extends Activity {
    private Database db;
    private LinearLayout listLayout;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state); db = new Database(this); showScreen(); loadCustomers();
    }

    private void showScreen() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(1);
        root.setPadding(16,16,16,16); root.setBackgroundColor(Color.rgb(246,248,247));
        TextView title = new TextView(this); title.setText("مدیریت مشتریان");
        title.setTextSize(24); title.setTextColor(Color.rgb(7,91,67));
        title.setGravity(Gravity.CENTER); title.setPadding(5,15,5,20); root.addView(title);
        Button add = new Button(this); add.setText("＋ افزودن مشتری جدید"); add.setAllCaps(false);
        add.setOnClickListener(v -> addCustomerDialog()); root.addView(add);
        ScrollView scroll = new ScrollView(this); listLayout = new LinearLayout(this);
        listLayout.setOrientation(1); scroll.addView(listLayout); root.addView(scroll); setContentView(root);
    }

    private void loadCustomers() {
        listLayout.removeAllViews(); Cursor c=db.customers();
        if (c.getCount()==0) { TextView e=new TextView(this); e.setText("هنوز مشتری ثبت نشده است."); e.setGravity(Gravity.CENTER); e.setPadding(10,30,10,30); listLayout.addView(e); }
        while(c.moveToNext()) {
            String name=c.getString(c.getColumnIndexOrThrow("name"));
            String phone=c.getString(c.getColumnIndexOrThrow("phone"));
            TextView row=new TextView(this); row.setText(name+"\n"+((phone==null||phone.isEmpty())?"شماره تماس ثبت نشده":"شماره تماس: "+phone));
            row.setTextSize(17); row.setTextColor(Color.rgb(7,91,67)); row.setPadding(15,18,15,18);
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,5,0,10); listLayout.addView(row,p);
        }
        c.close();
    }

    private void addCustomerDialog() {
        LinearLayout form=new LinearLayout(this); form.setOrientation(1); form.setPadding(20,10,20,10);
        EditText name=new EditText(this); name.setHint("نام مشتری"); form.addView(name);
        EditText phone=new EditText(this); phone.setHint("شماره تماس");
        phone.setInputType(android.text.InputType.TYPE_CLASS_PHONE); form.addView(phone);
        AlertDialog d=new AlertDialog.Builder(this).setTitle("ثبت مشتری جدید").setView(form)
            .setPositiveButton("ثبت",null).setNegativeButton("انصراف",null).create();
        d.setOnShowListener(x -> d.getButton(-1).setOnClickListener(v -> {
            String n=name.getText().toString().trim();
            if(n.isEmpty()){name.setError("نام مشتری را وارد کن");return;}
            db.addCustomer(n,phone.getText().toString().trim(),"");
            d.dismiss(); loadCustomers(); Toast.makeText(this,"مشتری ثبت شد.",Toast.LENGTH_SHORT).show();
        }));
        d.show();
    }
}
